/*
 * algorytm.cpp
 * 
 * 
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    int a;
	cout<<"Podaj liczbę"<<endl;
    cin>>a;
    while (a>0 && a<100);
        if (a>0 && a<100) 
            break;
        else 
            
    
    for(int i=2; i = a ;i+=2) 
        {
         cout<< i << ""<<endl;
         
         if ();
            cout<<"Liczba jest parzysta"<<a<<endl;
        else
            cout<<"Liczba jest nieparzysta" <<a<<endl;
        }
        
	return 0;
}

