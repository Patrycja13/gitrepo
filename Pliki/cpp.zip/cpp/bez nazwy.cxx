/*
 * bez nazwy.cxx
 */


#include <iostream>
#include <math.h>

int main(int argc, char **argv)
{
    int r = 0;
    cout << "Podaj promień" ;
    cin >> r ;
    cout << "Pole :" < M_PI * r * r << endl; 
	
	return 0;
}

