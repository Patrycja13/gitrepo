/*
 * petle_cw2.cpp
 */



#include <iostream>
using namespace std;
int main()
{
    
	
    for (int i = 11;i < 30; i++)
    cout << " " << i << " ";
  
	return 0;
}

