/*
 * petle_cw8.cpp
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    int 
	
	return 0;
}

