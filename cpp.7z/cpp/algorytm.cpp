/*
 * algorytm.cpp
 * 
 * 
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    int a;
	cout<<"Podaj liczbę"<<endl;
    cin>>a;
    
    if (0 < a && a < 100)
    for (int i = a>0 && int i = a<100, )    

	return 0;
}

