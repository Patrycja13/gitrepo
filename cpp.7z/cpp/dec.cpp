/*
 * dec.cpp
 * 
 * Copyright 2018  <>
 *
 * 
 * 
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
	int liczba=120;
    do{
        while()
        }
	return 0;
}

