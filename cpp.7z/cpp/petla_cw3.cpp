/*
 * petla_cw3.cpp
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    int n = 0;
	cin >> n;
    cout <<" Podaj liczbę "<<endl;
    for(int i=0;i<=n;i++)
	cout <<i*i<<endl;
    system ("pause");
    return 0;
    
}

